CUDA_VISIBLE_DEVICES=3  python3 pet_id/train_net.py --config-file ./configs/baselinev1_s200.yaml # model1

