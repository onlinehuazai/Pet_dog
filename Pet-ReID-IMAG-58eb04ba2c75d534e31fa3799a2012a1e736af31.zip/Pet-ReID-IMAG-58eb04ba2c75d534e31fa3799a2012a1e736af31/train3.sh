CUDA_VISIBLE_DEVICES=2  python3 pet_id/train_net.py --config-file ./configs/baselinev1_s101_288.yaml # model

