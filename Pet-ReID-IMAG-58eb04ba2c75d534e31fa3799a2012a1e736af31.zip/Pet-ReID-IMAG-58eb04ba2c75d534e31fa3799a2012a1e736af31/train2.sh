CUDA_VISIBLE_DEVICES=1  python3 pet_id/train_net.py --config-file ./configs/baselinev1_s101_256.yaml # model1

