CUDA_VISIBLE_DEVICES=0  python3 pet_id/train_net.py --config-file ./configs/baselinev1_s101_224.yaml # model1

